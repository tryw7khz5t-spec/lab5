#include <locale.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    char sentence[1024];
    const char delimiters[] = " \t\r\n,.;:!?()-\"";

    setlocale(LC_COLLATE, "");

    printf("Введите предложение:\n");
    if (fgets(sentence, sizeof sentence, stdin) == NULL)
    {
        return 0;
    }

    char *max_word = strtok(sentence, delimiters);
    if (max_word == NULL)
    {
        printf("В предложении нет слов.\n");
        return 0;
    }

    char *word;
    while ((word = strtok(NULL, delimiters)) != NULL)
    {
        if (strcoll(word, max_word) > 0)
        {
            max_word = word;
        }
    }

    printf("Самое большое слово: %s\n", max_word);
    return 0;
}